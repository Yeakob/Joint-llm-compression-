# Offline end-to-end test kit

Runs the full notebook without network or GPU, on tiny random models and schema-identical
synthetic data. Numbers are meaningless; this verifies the pipeline mechanics only.

```bash
pip install torch transformers datasets accelerate safetensors torchao lm_eval[ifeval] gguf \
    sentencepiece protobuf pandas scipy matplotlib tabulate psutil pyyaml nbclient ipykernel
git clone https://github.com/ggml-org/llama.cpp && cmake -S llama.cpp -B llama.cpp/build -DLLAMA_CURL=OFF \
  && cmake --build llama.cpp/build -j --target llama-quantize llama-perplexity llama-bench llama-imatrix
python -c "from pathlib import Path; from fixtures import *; d=Path('fx'); t=make_tokenizer(d); make_models(d,t)"
cp fixtures.py fx/
# edit the paths at the top of run_nb.py (fixtures dir, drive root, llama.cpp dir), then:
python run_nb.py joint_llm_compression_research.ipynb executed.ipynb
python test_prune_quant.py && python test_train.py      # unit tests (tiny.py)
```
