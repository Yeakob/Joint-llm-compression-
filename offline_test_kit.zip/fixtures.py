"""Offline fixtures: a real SentencePiece tokenizer with a ChatML template, tiny random Llama
teacher/student, and synthetic datasets with the exact schemas of UltraChat/GSM8K/WikiText/IFEval.
Used only to exercise the full pipeline end-to-end without network access."""
import json
import random
from pathlib import Path

import sentencepiece as spm
import torch
from transformers import LlamaConfig, LlamaForCausalLM, LlamaTokenizerFast

CHATML = ("{% for m in messages %}<|im_start|>{{ m['role'] }}\n{{ m['content'] }}<|im_end|>\n{% endfor %}"
          "{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}")
WORDS = ("the of and to in a is that for it as was with be by on not he I this are or his from at which but "
         "have an they you were her she there one all we their can has been if more when will would who so no "
         "number apples sold clips May total each how many solve step answer write explain lowercase haiku "
         "poem summary history science river mountain city music letter words paragraph").split()


def sentences(n, seed=0):
    r = random.Random(seed)
    return [" ".join(r.choice(WORDS) for _ in range(r.randint(6, 20))).capitalize() + "." for _ in range(n)]


def make_tokenizer(d: Path):
    d.mkdir(parents=True, exist_ok=True)
    corpus = d / "corpus.txt"
    corpus.write_text("\n".join(sentences(3000) + [f"{a} + {b} = {a+b} #### {a+b}" for a in range(40) for b in range(10)]))
    spm.SentencePieceTrainer.train(input=str(corpus), model_prefix=str(d / "sp"), vocab_size=384, model_type="bpe",
                                   user_defined_symbols=["<|im_start|>", "<|im_end|>"], byte_fallback=True,
                                   bos_id=1, eos_id=2, unk_id=0, pad_id=-1, character_coverage=1.0)
    tdir = d / "tok"
    tdir.mkdir(exist_ok=True)
    (tdir / "tokenizer.model").write_bytes((d / "sp.model").read_bytes())
    (tdir / "tokenizer_config.json").write_text(json.dumps({"tokenizer_class": "LlamaTokenizer",
                                                            "add_bos_token": False, "legacy": False}))
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(str(tdir))
    assert len(tok) == 384, len(tok)
    tok.chat_template = CHATML
    tok.eos_token = "<|im_end|>"
    tok.pad_token = "<|im_end|>"
    return tok


def make_models(d: Path, tok):
    V = len(tok)
    for name, (h, L, heads, kv, inter) in {"student": (128, 2, 4, 2, 512), "teacher": (128, 3, 4, 2, 512)}.items():
        torch.manual_seed(0 if name == "student" else 1)
        cfg = LlamaConfig(vocab_size=V, hidden_size=h, num_hidden_layers=L, num_attention_heads=heads,
                          num_key_value_heads=kv, intermediate_size=inter, max_position_embeddings=1024,
                          tie_word_embeddings=True, bos_token_id=1, eos_token_id=tok.eos_token_id,
                          pad_token_id=tok.pad_token_id)
        m = LlamaForCausalLM(cfg)
        m.generation_config.eos_token_id = tok.eos_token_id
        m.save_pretrained(d / name)
        tok.save_pretrained(d / name)
        (d / name / "tokenizer.model").write_bytes((d / "sp.model").read_bytes())   # for convert_hf_to_gguf
    return str(d / "student"), str(d / "teacher")


def fake_datasets():
    r = random.Random(0)
    def uc(n, off):
        return [{"messages": [{"role": "user", "content": s}, {"role": "assistant", "content": t}]}
                for s, t in zip(sentences(n, off), sentences(n, off + 7))]
    def gsm(n, off):
        out = []
        for i in range(n):
            a, b = r.randint(1, 40), r.randint(1, 9)
            out.append({"question": f"Question {off}-{i}: there are {a} apples and {b} more are sold. How many in total?",
                        "answer": f"{a} + {b} = <<{a}+{b}={a+b}>>{a+b}\n#### {a+b}"})
        return out
    ife = [{"key": i, "prompt": f"Write a short poem number {i} about the river. Use all lowercase letters.",
            "instruction_id_list": ["change_case:english_lowercase"],
            "kwargs": [{"num_highlights": None}]} for i in range(12)]
    wt = {"validation": [{"text": s + "\n"} for s in sentences(300, 5)],
          "test": [{"text": s + "\n"} for s in sentences(300, 9)]}
    table = {
        ("HuggingFaceH4/ultrachat_200k", "train_sft"): uc(120, 1),
        ("HuggingFaceH4/ultrachat_200k", "test_sft"): uc(40, 100),
        ("openai/gsm8k", "train"): gsm(60, 1), ("openai/gsm8k", "test"): gsm(20, 2),
        ("google/IFEval", "train"): ife,
        ("Salesforce/wikitext", "validation"): wt["validation"], ("Salesforce/wikitext", "test"): wt["test"],
    }

    def _load(repo, config=None, split=None, revision=None):
        return table[(repo, split)]
    return _load
