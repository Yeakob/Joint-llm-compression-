import sys, copy, torch, json, shutil, tempfile
sys.path.insert(0,'/home/claude/build'); sys.path.insert(0,'/home/claude/build/tests')
from pathlib import Path
from tiny import tiny, Tok
from jlc.config import make_config
from jlc import train as T, prune as P, quant as Q
cfg=make_config('smoke'); cfg.train.optimizer='adamw'; cfg.train.gradient_checkpointing=True
cfg.train.stage_steps=10; cfg.train.ckpt_every=4; cfg.train.log_every=2; cfg.train.dev_eval_every=5
cfg.train.micro_batch=2; cfg.train.grad_accum=2; cfg.paths.local_root=tempfile.mkdtemp()
cfg.alt.cycle_steps=2
torch.manual_seed(0)
def ex(n):
    out=[]
    for i in range(n):
        L=int(torch.randint(10,40,(1,)))
        ids=torch.randint(2,300,(L,)).tolist(); lab=[-100]*5+ids[5:]
        out.append({'input_ids':ids,'labels':lab})
    return out
data=ex(30); dev=ex(6); tok=Tok()
root=Path(tempfile.mkdtemp())
def run(spec, model, teacher=None, tag='x', crash_at=None):
    out=root/tag
    tr=T.Trainer(model,tok,data,spec,cfg,out,seed=0,log_path=root/f'{tag}.jsonl',logit_teacher=teacher,dev_examples=dev,root=root)
    if crash_at:
        orig=tr._loss; cnt={'n':0}
        def bad(b,ph):
            cnt['n']+=1
            if cnt['n']>crash_at*cfg.train.grad_accum: raise KeyboardInterrupt('simulated disconnect')
            return orig(b,ph)
        tr._loss=bad
    return tr.run()
base=tiny(); teacher=copy.deepcopy(base).eval()
s=P.inspect_structure(base); kv_n,mlp_n,_=P.keep_counts(s,0.7,0.5,64)
specs={
 'E1_kd': T.TrainSpec('kd',10,use_logit_kd=True),
 'E5_kdqat': T.TrainSpec('kdqat',10,use_logit_kd=True,qat=True),
 'E8_joint': T.TrainSpec('joint',10,use_logit_kd=True,qat=True,gates=True,kv_keep=kv_n,mlp_keep=mlp_n,hard_prune_at=0.6),
 'E9_alt': T.TrainSpec('alt',10,use_logit_kd=True,qat=True,gates=True,alternating=True,kv_keep=kv_n,mlp_keep=mlp_n),
 'H4_noqai': T.TrainSpec('noqai',10,use_logit_kd=True,qat=True,gates=True,kv_keep=kv_n,mlp_keep=mlp_n,qat_aware_gating=False),
}
for name,spec in specs.items():
    m=copy.deepcopy(base); r=run(spec,m,teacher,tag=name)
    logs=[json.loads(l) for l in open(root/f'{name}.jsonl')]
    print(name, 'steps',r['steps'],'conv',r['qat_converted_layers'],'plan', bool(r['plan']), 'params',sum(p.numel() for p in m.parameters()),
          'last',{k:round(v,3) for k,v in logs[-3].items() if k in('L_KD','L_Q','L_CE','R_SP','gate_kv_mean')})
    if spec.qat:  # weights on Q4_0 grid
        w=m.model.layers[0].mlp.down_proj.weight.data; assert torch.equal(Q.q4_0_dequant(w),w), 'not on grid'
    if name=='E9_alt': print('  alt phases seen', sorted({l.get('alt_phase') for l in logs if 'alt_phase' in l}, key=str))
# resume determinism (joint, crash at step 6 -> after hard prune at 6 and ckpt at 4)
for crash in (3,7):
    m1=copy.deepcopy(base); run(specs['E8_joint'],m1,teacher,tag=f'det_ref{crash}')
    m2=copy.deepcopy(base)
    try: run(specs['E8_joint'],m2,teacher,tag=f'det_res{crash}',crash_at=crash)
    except KeyboardInterrupt as e: print('crashed at',crash, '->', sorted(p.name for p in (root/f'det_res{crash}'/'train').glob('step_*')))
    m3=copy.deepcopy(base); run(specs['E8_joint'],m3,teacher,tag=f'det_res{crash}')
    d=max((a-b).abs().max().item() for a,b in zip(m1.state_dict().values(),m3.state_dict().values()))
    print(f'resume(crash@{crash}) vs uninterrupted max diff:',d)
print('OK')
