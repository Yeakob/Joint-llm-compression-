import torch
from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast
def tiny(seed=0, n_kv=3, heads=6, inter=256, layers=2, tie=True):
    torch.manual_seed(seed)
    c=LlamaConfig(vocab_size=320,hidden_size=96,intermediate_size=inter,num_hidden_layers=layers,num_attention_heads=heads,
                  num_key_value_heads=n_kv,head_dim=32,max_position_embeddings=256,tie_word_embeddings=tie)
    m=LlamaForCausalLM(c).eval()
    return m
class Tok:
    eos_token_id=1; pad_token_id=1
    def __call__(self, text, return_tensors=None):
        ids=[2+ (ord(ch)%300) for ch in text]
        class O: pass
        o=O(); o.input_ids=torch.tensor([ids]); return o
