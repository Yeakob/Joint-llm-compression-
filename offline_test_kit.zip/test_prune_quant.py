import sys, copy, torch, numpy as np
sys.path.insert(0,'/home/claude/build'); sys.path.insert(0,'/home/claude/build/tests')
from tiny import tiny, Tok
from jlc import prune as P, quant as Q
import gguf
from gguf import quants
# 1) Q4_0 / Q8_0 bit exactness vs gguf-py reference
for t,fn in [(gguf.GGMLQuantizationType.Q4_0,Q.q4_0_dequant),(gguf.GGMLQuantizationType.Q8_0,Q.q8_0_dequant)]:
    x=np.random.randn(64,256).astype(np.float32)*0.05; x[3,:32]=0
    ref=quants.dequantize(quants.quantize(x,t),t)
    got=fn(torch.from_numpy(x)).numpy()
    print(t.name,'max diff vs gguf-py:',np.abs(ref-got).max()); assert np.abs(ref-got).max()==0
# STE grad
w=torch.randn(8,64,requires_grad=True); Q.fake_quant_q4_0(w).sum().backward(); assert torch.allclose(w.grad,torch.ones_like(w))
m=tiny(); s=P.inspect_structure(m); print(s)
tok=Tok(); ids=torch.randint(2,300,(2,40))
batches=[{'input_ids':ids,'attention_mask':torch.ones_like(ids),'labels':ids}]
for meth in ['activation','taylor','magnitude']:
    imp=P.compute_importance(m,s,batches,meth); assert len(imp['kv'])==2 and imp['kv'][0].shape==(3,)
kv_n,mlp_n,info=P.keep_counts(s,0.7,0.5,64); print('keep',kv_n,mlp_n,info)
plan=P.plan_from_importance(imp,kv_n,mlp_n,s)
# masked reference
mb=P.MaskBank(m,s); mb.apply_plan(plan)
with torch.no_grad(): ref=m(ids[:1]).logits
mb.remove()
pm=copy.deepcopy(m); rep=P.physically_prune(pm,plan); print(rep)
v=P.verify_pruned(pm,tok,s,plan,ref_logits=ref,probe_ids=ids[:1]); print(v)
# save/reload
import tempfile
from transformers import AutoModelForCausalLM
d=tempfile.mkdtemp(); pm.save_pretrained(d); re=AutoModelForCausalLM.from_pretrained(d)
with torch.no_grad(): print('reload diff',(re(ids[:1]).logits-pm(ids[:1]).logits).abs().max().item())
# gates + fold equivalence
gm=copy.deepcopy(m); gb=P.GateBank(gm,s,init=0.5)
with torch.no_grad():
    gb.kv_logits.normal_(); gb.mlp_logits.normal_()
p2=gb.to_plan(kv_n,mlp_n); kvv,mlpv=gb.gate_values_for(p2)
# reference: gated model with non-kept gates zeroed
with torch.no_grad():
    for i in range(s.n_layers):
        mk=torch.zeros(s.n_kv,dtype=torch.bool); mk[p2.kv_keep[i]]=True; gb.kv_logits[i][~mk]=-1e4
        mm=torch.zeros(s.inter,dtype=torch.bool); mm[p2.mlp_keep[i]]=True; gb.mlp_logits[i][~mm]=-1e4
    ref2=gm(ids[:1]).logits
gb.remove(); P.physically_prune(gm,p2,fold_gates=(kvv,mlpv))
with torch.no_grad(): print('fold diff',(gm(ids[:1]).logits-ref2).abs().max().item())
r=gb.regularizer(0.66,0.5); r.backward(); print('R_SP',r.item())
# QAT on pruned
qm=copy.deepcopy(pm); names=Q.prepare_qat(qm); print('fq layers',len(names))
out=qm(ids,labels=ids); out.loss.backward(); print('qat loss',out.loss.item(), qm.model.layers[0].mlp.down_proj.weight.grad.abs().sum().item()>0)
assert 'lm_head' not in ' '.join(names)
print(sorted(qm.state_dict().keys())==sorted(pm.state_dict().keys()))
Q.set_fake_quant(qm,False)
with torch.no_grad(): print('fq off == fp', (qm(ids[:1]).logits-pm(ids[:1]).logits).abs().max().item())
Q.set_fake_quant(qm,True)
with torch.no_grad(): a=qm(ids[:1]).logits
Q.convert_qat(qm)
with torch.no_grad(): print('convert == fq forward', (qm(ids[:1]).logits-a).abs().max().item(), type(qm.model.layers[0].mlp.down_proj))
qm2=copy.deepcopy(pm); Q.prepare_qat(qm2,backend='torchao_intx'); print('torchao loss',qm2(ids,labels=ids).loss.item())
sm=copy.deepcopy(pm); errs=Q.snap_model(sm,'Q4_0'); print('snap mean rel err',np.mean(list(errs.values())))
# unsupported arch diagnostic
from transformers import Phi3Config, Phi3ForCausalLM
try:
    P.inspect_structure(Phi3ForCausalLM(Phi3Config(vocab_size=100,hidden_size=64,intermediate_size=128,num_hidden_layers=1,num_attention_heads=4,num_key_value_heads=2,pad_token_id=0)))
except P.UnsupportedArchitecture as e: print('Phi3 correctly refused:', str(e).splitlines()[1][:80])
print('ALL OK')
