import os, sys, nbformat, time
from nbclient import NotebookClient
os.environ.update({"JLC_OFFLINE_FIXTURES":"/home/claude/fx","JLC_DRIVE_ROOT":"/home/claude/e2e/drive",
  "JLC_LOCAL_ROOT":"/home/claude/e2e/local","JLC_SKIP_PIP":"1","JLC_LLAMA_DIR":"/home/claude/llama/llama.cpp",
  "TOKENIZERS_PARALLELISM":"false","NLTK_ALLOW_PROXIED_URLOPEN":"1"})
nb=nbformat.read(sys.argv[1],as_version=4)
t=time.time()
c=NotebookClient(nb,timeout=3600,kernel_name="python3",allow_errors=False,resources={"metadata":{"path":"/home/claude/e2e"}})
try:
    c.execute()
    print("EXECUTED OK in", round(time.time()-t), "s")
finally:
    nbformat.write(nb, sys.argv[2])
